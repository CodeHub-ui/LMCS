// Placeholder for UIUtil.java
