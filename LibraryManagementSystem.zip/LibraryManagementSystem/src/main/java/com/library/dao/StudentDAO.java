// Placeholder for StudentDAO.java
package com.library.dao;

import com.library.model.Student;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentDAO {
    public int getTotalStudents() {
        String sql = "SELECT COUNT(*) FROM students";
        try (Connection conn = DatabaseUtil.getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public int getBlockedStudents() {
        String sql = "SELECT COUNT(*) FROM students WHERE active = FALSE";
        try (Connection conn = DatabaseUtil.getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public List<Student> getAllStudents(boolean active) {
        String sql = "SELECT * FROM students WHERE active = ?";
        List<Student> students = new ArrayList<>();
        try (Connection conn = DatabaseUtil.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setBoolean(1, active);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Student s = new Student();
                s.setId(rs.getInt("id"));
                s.setName(rs.getString("name"));
                s.setStudentId(rs.getString("student_id"));
                s.setEmail(rs.getString("email"));
                s.setMobile(rs.getString("mobile"));
                s.setRfid(rs.getString("rfid"));
                s.setActive(rs.getBoolean("active"));
                students.add(s);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return students;
    }

    public List<Student> searchStudents(String query) {
        String sql = "SELECT * FROM students WHERE name LIKE ? OR student_id LIKE ?";
        List<Student> students = new ArrayList<>();
        try (Connection conn = DatabaseUtil.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, "%" + query + "%");
            stmt.setString(2, "%" + query + "%");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Student s = new Student();
                s.setId(rs.getInt("id"));
                s.setName(rs.getString("name"));
                s.setStudentId(rs.getString("student_id"));
                s.setEmail(rs.getString("email"));
                s.setMobile(rs.getString("mobile"));
                s.setRfid(rs.getString("rfid"));
                s.setActive(rs.getBoolean("active"));
                students.add(s);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return students;
    }

    public boolean register(Student student) {
        String sql = "INSERT INTO students (name, student_id, email, mobile, rfid) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseUtil.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, student.getName());
            stmt.setString(2, student.getStudentId());
            stmt.setString(3, student.getEmail());
            stmt.setString(4, student.getMobile());
            stmt.setString(5, student.getRfid());
            stmt.executeUpdate();
            LogDAO.log("Student registered: " + student.getName());
            return true;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean blockStudent(int id) {
        String sql = "UPDATE students SET active = FALSE WHERE id = ?";
        try (Connection conn = DatabaseUtil.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
            LogDAO.log("Student blocked: ID " + id);
            return true;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean unblockStudent(int id) {
        String sql = "UPDATE students SET active = TRUE WHERE id = ?";
        try (Connection conn = DatabaseUtil.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
            LogDAO.log("Student unblocked: ID " + id);
            return true;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public Student getStudentById(int id) {
        String sql = "SELECT * FROM students WHERE id = ?";
        try (Connection conn = DatabaseUtil.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Student s = new Student();
                s.setId(rs.getInt("id"));
                s.setName(rs.getString("name"));
                s.setStudentId(rs.getString("student_id"));
                s.setEmail(rs.getString("email"));
                s.setMobile(rs.getString("mobile"));
                s.setRfid(rs.getString("rfid"));
                s.setActive(rs.getBoolean("active"));
                return s;
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public boolean updateStudent(Student student) {
        String sql = "UPDATE students SET name = ?, student_id = ?, email = ?, mobile = ?, rfid = ?, active = ? WHERE id = ?";
        try (Connection conn = DatabaseUtil.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, student.getName());
            stmt.setString(2, student.getStudentId());
            stmt.setString(3, student.getEmail());
            stmt.setString(4, student.getMobile());
            stmt.setString(5, student.getRfid());
            stmt.setBoolean(6, student.isActive());
            stmt.setInt(7, student.getId());
            stmt.executeUpdate();
            LogDAO.log("Student updated: ID " + student.getId());
            return true;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean deleteStudent(int id) {
        String sql = "DELETE FROM students WHERE id = ?";
        try (Connection conn = DatabaseUtil.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
            LogDAO.log("Student deleted: ID " + id);
            return true;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }
}
