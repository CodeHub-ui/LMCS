// Placeholder for FacultyDAO.java
package com.library.dao;

import com.library.model.Faculty;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FacultyDAO {
    public int getTotalFaculty() {
        String sql = "SELECT COUNT(*) FROM faculty";
        try (Connection conn = DatabaseUtil.getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public int getBlockedFaculty() {
        String sql = "SELECT COUNT(*) FROM faculty WHERE active = FALSE";
        try (Connection conn = DatabaseUtil.getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public List<Faculty> getAllFaculty(boolean active) {
        String sql = "SELECT * FROM faculty WHERE active = ?";
        List<Faculty> faculty = new ArrayList<>();
        try (Connection conn = DatabaseUtil.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setBoolean(1, active);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Faculty f = new Faculty();
                f.setId(rs.getInt("id"));
                f.setName(rs.getString("name"));
                f.setFacultyId(rs.getString("faculty_id"));
                f.setEmail(rs.getString("email"));
                f.setMobile(rs.getString("mobile"));
                f.setActive(rs.getBoolean("active"));
                faculty.add(f);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return faculty;
    }
}
