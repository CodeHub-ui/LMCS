// Placeholder for DatabaseUtil.java
package com.library.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseUtil {
    private static final String URL = "jdbc:h2:~/librarydb"; // Change to MySQL if needed
    private static final String USER = "sa";
    private static final String PASS = "";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    public static void initializeDatabase() {
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
            // Create tables
            stmt.execute("CREATE TABLE IF NOT EXISTS admins (id INT AUTO_INCREMENT PRIMARY KEY, admin_id VARCHAR(50), password_hash VARCHAR(255))");
            stmt.execute("CREATE TABLE IF NOT EXISTS students (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100), student_id VARCHAR(50), email VARCHAR(100), mobile VARCHAR(15), rfid VARCHAR(50), active BOOLEAN DEFAULT TRUE)");
            stmt.execute("CREATE TABLE IF NOT EXISTS faculty (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100), faculty_id VARCHAR(50), email VARCHAR(100), mobile VARCHAR(15), active BOOLEAN DEFAULT TRUE)");
            stmt.execute("CREATE TABLE IF NOT EXISTS categories (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100))");
            stmt.execute("CREATE TABLE IF NOT EXISTS books (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100), author VARCHAR(100), barcode VARCHAR(50), category_id INT, FOREIGN KEY (category_id) REFERENCES categories(id))");
            stmt.execute("CREATE TABLE IF NOT EXISTS logs (id INT AUTO_INCREMENT PRIMARY KEY, action VARCHAR(255), timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}