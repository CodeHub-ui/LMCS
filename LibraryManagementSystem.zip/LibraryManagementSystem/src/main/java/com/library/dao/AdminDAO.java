// Placeholder for AdminDAO.java
package com.library.dao;

import com.library.model.Admin;
import com.library.util.PasswordUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AdminDAO {
    public boolean register(Admin admin) {
        String sql = "INSERT INTO admins (admin_id, password_hash) VALUES (?, ?)";
        try (Connection conn = DatabaseUtil.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, admin.getAdminId());
            stmt.setString(2, PasswordUtil.hashPassword(admin.getPasswordHash()));
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public Admin login(String adminId, String password) {
        String sql = "SELECT * FROM admins WHERE admin_id = ?";
        try (Connection conn = DatabaseUtil.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, adminId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next() && PasswordUtil.checkPassword(password, rs.getString("password_hash"))) {
                Admin admin = new Admin();
                admin.setId(rs.getInt("id"));
                admin.setAdminId(rs.getString("admin_id"));
                admin.setPasswordHash(rs.getString("password_hash"));
                return admin;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
