// Placeholder for Admin.java
package com.library.model;

public class Admin {
    private int id;
    private String adminId;
    private String passwordHash;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getAdminId() { return adminId; }
    public void setAdminId(String adminId) { this.adminId = adminId; }
    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }
}