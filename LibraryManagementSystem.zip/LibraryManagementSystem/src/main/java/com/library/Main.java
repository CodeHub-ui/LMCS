// Placeholder for Main.java
package com.library;

import com.library.controller.LoginController;
import com.library.dao.DatabaseUtil;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
        // Initialize database
        DatabaseUtil.initializeDatabase();

        // Load Login Page
        Scene scene = new LoginController(primaryStage).getScene();
        primaryStage.setTitle("Library Management Admin Portal");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}