package com.library.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object (DAO) for IssuedBook entities.
 * Handles operations related to book issuing and returning, interacting with the issued_books table.
 */
public class IssuedBookDAO {

    /**
     * Retrieves a list of books issued to a specific student.
     * Returns an array of strings for each book: [book_title, barcode, author].
     *
     * @param studentId the ID of the student
     * @return a list of string arrays representing issued books
     */
    public List<String[]> getIssuedBooks(int studentId) {  // Returns list of [book_title, barcode, author]
        String sql = "SELECT b.name, b.barcode, b.author FROM issued_books ib JOIN books b ON ib.book_id = b.id WHERE ib.student_id = ?";
        List<String[]> books = new ArrayList<>();
        try (Connection conn = DatabaseUtil.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                books.add(new String[]{rs.getString("name"), rs.getString("barcode"), rs.getString("author")});
            }
        } catch (SQLException e) {
            System.err.println("Error in getIssuedBooks: " + e.getMessage());
            e.printStackTrace();
        }
        return books;
    }

    /**
     * Issues a book to a student by inserting a record into the issued_books table.
     * Checks if the book is available before proceeding.
     *
     * @param studentId the ID of the student
     * @param barcode the barcode of the book to issue
     * @return true if the operation succeeds, false otherwise
     */
    public boolean issueBook(int studentId, String barcode) {
        // Get book ID from barcode
        int bookId = getBookIdByBarcode(barcode);
        if (bookId == -1) {
            System.err.println("Book with barcode " + barcode + " not found.");
            return false;
        }

        // Check if book is available
        String checkSql = "SELECT available FROM books WHERE id = ?";
        try (Connection conn = DatabaseUtil.getConnection(); PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
            checkStmt.setInt(1, bookId);
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next() && !rs.getBoolean("available")) {
                System.err.println("Book with barcode " + barcode + " is not available.");
                return false;
            }
        } catch (SQLException e) {
            System.err.println("Error checking book availability: " + e.getMessage());
            e.printStackTrace();
            return false;
        }

        // Proceed with issuing
        String sql = "INSERT INTO issued_books (student_id, book_id) VALUES (?, ?)";
        try (Connection conn = DatabaseUtil.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            stmt.setInt(2, bookId);
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                // Update book availability to false
                String updateSql = "UPDATE books SET available = false WHERE id = ?";
                try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                    updateStmt.setInt(1, bookId);
                    updateStmt.executeUpdate();
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error in issueBook: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Returns a book by deleting the corresponding record from the issued_books table.
     * Uses the student's ID and the book's barcode to identify the record.
     * Updates the book's availability to true after successful return.
     *
     * @param studentId the ID of the student
     * @param barcode the barcode of the book to return
     * @return true if the operation succeeds, false otherwise
     */
    public boolean returnBook(int studentId, String barcode) {
        String sql = "DELETE FROM issued_books WHERE student_id = ? AND book_id = (SELECT id FROM books WHERE barcode = ?)";
        try (Connection conn = DatabaseUtil.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            stmt.setString(2, barcode);
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                // Update book availability to true
                String updateSql = "UPDATE books SET available = true WHERE barcode = ?";
                try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                    updateStmt.setString(1, barcode);
                    updateStmt.executeUpdate();
                }
                return true;
            } else {
                System.err.println("No issued book found for student " + studentId + " and barcode " + barcode);
            }
        } catch (SQLException e) {
            System.err.println("Error in returnBook: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Retrieves the count of books issued to a specific student.
     *
     * @param studentId the ID of the student
     * @return the number of issued books
     */
    public int getIssuedCountForStudent(int studentId) {
        String sql = "SELECT COUNT(*) FROM issued_books WHERE student_id = ?";
        try (Connection conn = DatabaseUtil.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("Error in getIssuedCountForStudent: " + e.getMessage());
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * Retrieves the book ID associated with a given barcode.
     *
     * @param barcode the barcode of the book
     * @return the book ID if found, -1 otherwise
     */
    public int getBookIdByBarcode(String barcode) {
        String sql = "SELECT id FROM books WHERE barcode = ?";
        try (Connection conn = DatabaseUtil.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, barcode);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            } else {
                System.err.println("No book found with barcode: " + barcode);
            }
        } catch (SQLException e) {
            System.err.println("Error in getBookIdByBarcode: " + e.getMessage());
            e.printStackTrace();
        }
        return -1;
    }
}
