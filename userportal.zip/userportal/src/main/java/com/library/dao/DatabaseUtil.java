package com.library.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseUtil {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/librarydb?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "2005";

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("MySQL JDBC Driver not found.", e);
        }

        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
    }

    public static void initializeDatabase() {
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {

            stmt.execute("CREATE TABLE IF NOT EXISTS admins (id INT AUTO_INCREMENT PRIMARY KEY, admin_id VARCHAR(50), password_hash VARCHAR(255))");
            // Commented out DROP TABLE statements to prevent data loss on each initialization
            //stmt.execute("DROP TABLE IF EXISTS issued_books");
            //stmt.execute("DROP TABLE IF EXISTS books");
            //stmt.execute("DROP TABLE IF EXISTS students");
            stmt.execute("CREATE TABLE IF NOT EXISTS students (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100), student_id VARCHAR(50) UNIQUE, email VARCHAR(100), mobile VARCHAR(15), rfid VARCHAR(50), course VARCHAR(100), active BOOLEAN DEFAULT TRUE)");
            stmt.execute("CREATE TABLE IF NOT EXISTS faculty (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100), faculty_id VARCHAR(50), email VARCHAR(100), mobile VARCHAR(15), active BOOLEAN DEFAULT TRUE)");
            stmt.execute("CREATE TABLE IF NOT EXISTS categories (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100))");
            stmt.execute("CREATE TABLE IF NOT EXISTS books (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100), author VARCHAR(100), barcode VARCHAR(50), category_id INT, available BOOLEAN DEFAULT TRUE, FOREIGN KEY (category_id) REFERENCES categories(id))");
            stmt.execute("CREATE TABLE IF NOT EXISTS issued_books (id INT AUTO_INCREMENT PRIMARY KEY, student_id INT, book_id INT, issue_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (student_id) REFERENCES students(id), FOREIGN KEY (book_id) REFERENCES books(id))");
            stmt.execute("CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100), user_id VARCHAR(50), email VARCHAR(100), mobile VARCHAR(15), rfid VARCHAR(50), course VARCHAR(100), password VARCHAR(255), active BOOLEAN DEFAULT TRUE)");
            stmt.execute("CREATE TABLE IF NOT EXISTS logs (id INT AUTO_INCREMENT PRIMARY KEY, action VARCHAR(255), timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

            // Removed sample data insertion to allow input through admin portal only

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void clearAllData() {
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
            stmt.execute("SET FOREIGN_KEY_CHECKS = 0");
            stmt.execute("DELETE FROM logs");
            stmt.execute("DELETE FROM issued_books");
            stmt.execute("DELETE FROM books");
            stmt.execute("DELETE FROM categories");
            stmt.execute("DELETE FROM faculty");
            stmt.execute("DELETE FROM students");
            stmt.execute("DELETE FROM admins");
            stmt.execute("SET FOREIGN_KEY_CHECKS = 1");
            System.out.println("All data cleared from the student portal database.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
