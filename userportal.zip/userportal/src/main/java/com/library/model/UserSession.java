package com.library.model;

/**
 * Manages the current user session for the user portal.
 * This class provides static methods to handle the logged-in user state.
 * It uses a singleton-like approach to maintain session state across the application.
 */
import com.library.model.User;

public class UserSession {
    private static User loggedInUser; // Holds the currently logged-in user

    /**
     * Retrieves the currently logged-in user.
     * @return the logged-in User object, or null if no user is logged in
     */
    public static User getLoggedInUser() { return loggedInUser; }

    /**
     * Sets the logged-in user for the session.
     * @param user the User object to set as logged in
     */
    public static void setLoggedInUser(User user) { loggedInUser = user; }

    /**
     * Logs in the user by setting the logged-in user.
     * @param user the User object to log in
     */
    public static void login(User user) { loggedInUser = user; }

    /**
     * Logs out the current user by clearing the session.
     * Sets the logged-in user to null.
     */
    public static void logout() { loggedInUser = null; }
}
