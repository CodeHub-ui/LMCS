// Placeholder for LoginController.java
package com.library.controller;

import com.library.dao.AdminDAO;
import com.library.model.Admin;
import com.library.model.Session;
import com.library.util.UIUtil;
import com.library.util.UILayoutConstants;
import com.library.util.PasswordUtil;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class LoginController {
    private Stage stage;

    public LoginController(Stage stage) {
        this.stage = stage;
    }

    public Scene getScene() {
    VBox contentBox = new VBox(10);
    contentBox.setPadding(UILayoutConstants.PADDING);
    contentBox.setAlignment(UILayoutConstants.CENTER_ALIGNMENT);

    Label heading = new Label("Admin Portal");
    heading.setStyle("-fx-font-size:20px; -fx-font-weight:600; -fx-text-fill:#0f172a; -fx-padding:0 0 8 0;");
        TextField adminIdField = new TextField();
        adminIdField.setPromptText("Admin ID");
    PasswordField passwordField = new PasswordField();
    passwordField.setPromptText("Password");

    TextField plainPassword = new TextField();
    plainPassword.setPromptText("Password");

    // Show password checkbox: when selected show plain text field, otherwise show masked PasswordField
    CheckBox showPassword = new CheckBox("Show Password");
    // Bind text bidirectionally so both fields reflect the same content
    plainPassword.textProperty().bindBidirectional(passwordField.textProperty());
    // Toggle visibility/managed properties
    plainPassword.managedProperty().bind(showPassword.selectedProperty());
    plainPassword.visibleProperty().bind(showPassword.selectedProperty());
    passwordField.managedProperty().bind(showPassword.selectedProperty().not());
    passwordField.visibleProperty().bind(showPassword.selectedProperty().not());

        Hyperlink forgotPassword = new Hyperlink("Forgot Password?");
        forgotPassword.setOnAction(e -> handleForgotPassword());

    Button registerBtn = new Button("Register");
    registerBtn.setStyle("-fx-background-color: transparent; -fx-border-color: #d1d5db; -fx-text-fill:#0f172a; -fx-background-radius:8; -fx-padding:8 14 8 14;");
        registerBtn.setOnAction(e -> UIUtil.switchScene(stage, new RegistrationController(stage).getScene()));

        Button loginBtn = new Button("Login");
    loginBtn.setStyle("-fx-background-color: linear-gradient(#1f7aec, #0f62fe); -fx-text-fill: white; -fx-font-weight:600; -fx-background-radius:8; -fx-padding:8 14 8 14;");
        loginBtn.setOnAction(e -> {
            String adminId = adminIdField.getText() == null ? "" : adminIdField.getText().trim();
            String pwd = passwordField.getText(); // plainPassword is bound, so either works
            Admin admin = new AdminDAO().login(adminId, pwd);
            if (admin != null) {
                Session.setLoggedInAdmin(admin);
                UIUtil.switchScene(stage, new DashboardController(stage).getScene());
            } else {
                String err = AdminDAO.getLastErrorMessage();
                String msg = (err != null) ? err : "Invalid credentials";
                UIUtil.showAlert("Error", msg, Alert.AlertType.ERROR);
            }
        });

        contentBox.getChildren().addAll(heading, adminIdField, passwordField, plainPassword, showPassword, forgotPassword, registerBtn, loginBtn);

        return UIUtil.createScene(null, contentBox);
    }

    private void handleForgotPassword() {
        TextInputDialog emailDialog = new TextInputDialog();
        emailDialog.setTitle("Forgot Password");
        emailDialog.setHeaderText("Enter your email address");
        emailDialog.setContentText("Email:");
        emailDialog.showAndWait().ifPresent(email -> {
            if (!email.trim().isEmpty()) {
                AdminDAO dao = new AdminDAO();
                if (dao.sendPasswordResetEmail(email.trim())) {
                    UIUtil.showAlert("Success", "Password reset code sent to your email.", Alert.AlertType.INFORMATION);
                    // Show reset code dialog
                    showPasswordResetDialog(email.trim());
                } else {
                    UIUtil.showAlert("Error", "Email not found or failed to send.", Alert.AlertType.ERROR);
                }
            }
        });
    }

    private void showPasswordResetDialog(String email) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Reset Password");
        dialog.setHeaderText("Enter the reset code and new password");

        // Create the content
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField codeField = new TextField();
        codeField.setPromptText("Reset Code");
        PasswordField newPasswordField = new PasswordField();
        newPasswordField.setPromptText("New Password");
        PasswordField confirmPasswordField = new PasswordField();
        confirmPasswordField.setPromptText("Confirm New Password");

        grid.add(new Label("Reset Code:"), 0, 0);
        grid.add(codeField, 1, 0);
        grid.add(new Label("New Password:"), 0, 1);
        grid.add(newPasswordField, 1, 1);
        grid.add(new Label("Confirm Password:"), 0, 2);
        grid.add(confirmPasswordField, 1, 2);

        dialog.getDialogPane().setContent(grid);

        // Add buttons
        ButtonType resetButtonType = new ButtonType("Reset Password", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(resetButtonType, ButtonType.CANCEL);

        // Enable/Disable reset button depending on whether fields are filled
        Button resetButton = (Button) dialog.getDialogPane().lookupButton(resetButtonType);
        resetButton.setDisable(true);

        // Validation
        codeField.textProperty().addListener((observable, oldValue, newValue) -> {
            resetButton.setDisable(newValue.trim().isEmpty() || newPasswordField.getText().trim().isEmpty() ||
                                 confirmPasswordField.getText().trim().isEmpty());
        });
        newPasswordField.textProperty().addListener((observable, oldValue, newValue) -> {
            resetButton.setDisable(codeField.getText().trim().isEmpty() || newValue.trim().isEmpty() ||
                                 confirmPasswordField.getText().trim().isEmpty());
        });
        confirmPasswordField.textProperty().addListener((observable, oldValue, newValue) -> {
            resetButton.setDisable(codeField.getText().trim().isEmpty() || newPasswordField.getText().trim().isEmpty() ||
                                 newValue.trim().isEmpty());
        });

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == resetButtonType) {
                String code = codeField.getText().trim();
                String newPassword = newPasswordField.getText();
                String confirmPassword = confirmPasswordField.getText();

                if (!PasswordUtil.isValidPassword(newPassword)) {
                    UIUtil.showAlert("Error", "Password must be at least 8 characters with upper, lower, and digit.", Alert.AlertType.ERROR);
                    return null;
                }

                if (!newPassword.equals(confirmPassword)) {
                    UIUtil.showAlert("Error", "Passwords do not match.", Alert.AlertType.ERROR);
                    return null;
                }

                AdminDAO dao = new AdminDAO();
                Admin admin = dao.getAdminByEmail(email);
                if (admin != null) {
                    // For simplicity, we'll just update the password directly
                    // In a real application, you'd verify the reset code matches what was sent
                    if (dao.updatePassword(admin.getId(), newPassword)) {
                        UIUtil.showAlert("Success", "Password reset successfully!", Alert.AlertType.INFORMATION);
                        return dialogButton;
                    } else {
                        UIUtil.showAlert("Error", "Failed to reset password.", Alert.AlertType.ERROR);
                    }
                } else {
                    UIUtil.showAlert("Error", "Admin not found.", Alert.AlertType.ERROR);
                }
            }
            return null;
        });

        dialog.showAndWait();
    }
}
