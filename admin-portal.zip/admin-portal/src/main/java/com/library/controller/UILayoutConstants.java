package com.library.controller;

import javafx.geometry.Insets;
import javafx.geometry.Pos;

/**
 * A utility class to hold constants for UI layout and styling.
 * This ensures a consistent look and feel across the application.
 */
public final class UILayoutConstants {

    // Private constructor to prevent instantiation
    private UILayoutConstants() {}

    // --- Scene Dimensions ---
    public static final double SCENE_WIDTH = 1280;
    public static final double SCENE_HEIGHT = 800;

    // --- Padding and Alignment ---
    public static final Insets PADDING = new Insets(20);
    public static final Pos CENTER_ALIGNMENT = Pos.CENTER;

    // --- Styling Strings (JavaFX CSS) ---

    /**
     * Style for the root container to apply a full-screen background image.
     * The image is scaled to cover the entire area without repeating.
     */
    public static final String FULL_BACKGROUND_STYLE =
        "-fx-background-image: url('https://images.unsplash.com/photo-1521587760476-6c12a4b040da?q=80&w=2070');" +
        "-fx-background-size: cover;" +
        "-fx-background-position: center center;";

    /**
     * Style for the main content pane, giving it a modern, clean look.
     * It features a semi-transparent white background, rounded corners, and a subtle drop shadow.
     */
    public static final String CONTENT_PANE_STYLE =
        "-fx-background-color: rgba(255, 255, 255, 0.95);" +
        "-fx-background-radius: 15px;" +
        "-fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.1), 10, 0, 0, 5);";
}