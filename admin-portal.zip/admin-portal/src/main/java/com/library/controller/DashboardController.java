// Placeholder for DashboardController.java
package com.library.controller;

// Import statements for necessary classes from the library package and JavaFX
import com.library.Main;  // Added import for Main class to access getAppHostServices()
import com.library.dao.*;
import com.library.model.Session;
import com.library.util.UIUtil;
import com.library.util.UILayoutConstants;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.sql.SQLException;

/**
 * DashboardController handles the main dashboard scene for the Library Management System.
 * It displays an overview of library statistics and provides navigation buttons to different management sections.
 * The logout button is positioned at the top-right for easy access.
 */
public class DashboardController {
    private Stage stage; // The primary stage for the JavaFX application

    /**
     * Constructor for DashboardController.
     * @param stage The main stage of the application.
     */
    public DashboardController(Stage stage) {
        this.stage = stage;
    }

    /**
     * Creates a card VBox for navigation buttons.
     * @param text The text for the button.
     * @param color The background color for the card.
     * @param action The action to perform on click.
     * @return The VBox representing the card.
     */
    private VBox createCard(String text, String color, javafx.event.EventHandler<javafx.event.ActionEvent> action) {
        VBox card = new VBox();
        card.setAlignment(Pos.CENTER);
        card.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 12; -fx-padding: 20; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 6, 0, 0, 2); -fx-cursor: hand;");
        card.setPrefSize(180, 120);

        Label label = new Label(text);
        label.setStyle("-fx-font-size: 14px; -fx-font-weight: 600; -fx-text-fill: white; -fx-text-alignment: center;");
        label.setWrapText(true);

        card.getChildren().add(label);
        card.setOnMouseClicked(e -> action.handle(null));
        card.setOnMouseEntered(e -> card.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 12; -fx-padding: 20; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 8, 0, 0, 4); -fx-cursor: hand;"));
        card.setOnMouseExited(e -> card.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 12; -fx-padding: 20; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 6, 0, 0, 2); -fx-cursor: hand;"));

        return card;
    }

    /**
     * Creates and returns the dashboard scene.
     * Checks if an admin is logged in; if not, redirects to login.
     * Builds the UI with a BorderPane layout: top bar for logout, center for main content.
     * @return The Scene object for the dashboard.
     */
public Scene getScene() {
    // Top bar for reload and logout buttons
    Button reloadBtn = UIUtil.createStyledButton("🔄 Reload", "#22c55e", "#16a34a");
    reloadBtn.setOnAction(e -> {
        // Reload the dashboard by switching to a new instance
        UIUtil.switchScene(stage, new DashboardController(stage).getScene());
    });

    Button logoutBtn = UIUtil.createStyledButton("Logout", "#ef4444", "#dc2626");
    logoutBtn.setOnAction(e -> {
        Session.logout();
        UIUtil.switchScene(stage, new LoginController(stage).getScene());
    });

    HBox topBar = new HBox(10, reloadBtn, logoutBtn);
    topBar.setAlignment(Pos.TOP_LEFT);
    VBox centerLayout = new VBox(15); // Add 15px spacing between elements
    centerLayout.setPadding(UILayoutConstants.PADDING);
    centerLayout.setAlignment(UILayoutConstants.CENTER_ALIGNMENT);
    // Removed inline style to keep content area clean; styling is on the parent pane.
    centerLayout.setStyle("-fx-background-color: transparent;");

    // Main heading label
    Label heading = new Label("Library Management System");
    heading.setStyle("-fx-font-size: 24px; -fx-font-weight: 700; -fx-text-fill: #1e293b; -fx-padding: 0 0 12 0;");

    // Overview GridPane: Displays key statistics in a grid layout
    GridPane overview = new GridPane();
    overview.setHgap(20);
    overview.setVgap(15);
    overview.setAlignment(Pos.CENTER);
    // Light gray background for the overview section
    overview.setStyle("-fx-padding: 20; -fx-background-color: #f1f5f9; -fx-background-radius: 8;");

        // Labels for statistics, fetching with DAOs
        BookDAO bookDAO = new BookDAO();
        IssuedBookDAO issuedBookDAO = new IssuedBookDAO();
        int totalBooks = bookDAO.getTotalBooks();
        int issuedBooks = 0;
        try {
            issuedBooks = issuedBookDAO.getTotalIssuedBooks();
        } catch (SQLException ex) {
            UIUtil.showAlert("Error", "Failed to fetch issued book count.", Alert.AlertType.ERROR);
        }
        int availableBooks = totalBooks - issuedBooks;
        int pendingReturns = issuedBooks; // Pending returns are the issued books not yet returned

        Label totalBooksLabel = new Label("Total Books: " + totalBooks);
        totalBooksLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: 500; -fx-text-fill: #334155;");
        overview.add(totalBooksLabel, 0, 0);

        Label booksIssuedLabel = new Label("Books Issued: " + issuedBooks);
        booksIssuedLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: 500; -fx-text-fill: #334155;");
        overview.add(booksIssuedLabel, 1, 0);

        Label availableBooksLabel = new Label("Available Books: " + availableBooks);
        availableBooksLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: 500; -fx-text-fill: #334155;");
        overview.add(availableBooksLabel, 0, 1);

        Label pendingReturnsLabel = new Label("Pending Returns: " + pendingReturns);
        pendingReturnsLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: 500; -fx-text-fill: #334155;");
        overview.add(pendingReturnsLabel, 1, 1);

        Label studentsRegisteredLabel = new Label("Students Registered: " + new StudentDAO().getTotalStudents());
        studentsRegisteredLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: 500; -fx-text-fill: #334155;");
        overview.add(studentsRegisteredLabel, 0, 2);

        Label facultyRegisteredLabel = new Label("Faculty Registered: " + new FacultyDAO().getTotalFaculty());
        facultyRegisteredLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: 500; -fx-text-fill: #334155;");
        overview.add(facultyRegisteredLabel, 1, 2);

        // Navigation buttons with emojis for visual appeal and hover effects
        Button studentBtn = new Button("👨‍🎓 Student Management");
        studentBtn.setStyle("-fx-background-color: linear-gradient(#1f7aec, #0f62fe); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 16 10 16; -fx-cursor: hand; -fx-pref-width: 200;");
        // Hover effect: Reverse gradient
        studentBtn.setOnMouseEntered(e -> studentBtn.setStyle("-fx-background-color: linear-gradient(#0f62fe, #1f7aec); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 16 10 16; -fx-cursor: hand; -fx-pref-width: 200;"));
        studentBtn.setOnMouseExited(e -> studentBtn.setStyle("-fx-background-color: linear-gradient(#1f7aec, #0f62fe); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 16 10 16; -fx-cursor: hand; -fx-pref-width: 200;"));
        // Action: Switch to Student Management scene
        studentBtn.setOnAction(e -> UIUtil.switchScene(stage, new StudentManagementController(stage).getScene()));

        Button facultyBtn = new Button("👨‍🏫 Faculty Management");
        facultyBtn.setStyle("-fx-background-color: linear-gradient(#06b6d4, #0f62fe); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 16 10 16; -fx-cursor: hand; -fx-pref-width: 200;");
        // Hover effect: Reverse gradient
        facultyBtn.setOnMouseEntered(e -> facultyBtn.setStyle("-fx-background-color: linear-gradient(#0f62fe, #06b6d4); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 16 10 16; -fx-cursor: hand; -fx-pref-width: 200;"));
        facultyBtn.setOnMouseExited(e -> facultyBtn.setStyle("-fx-background-color: linear-gradient(#06b6d4, #0f62fe); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 16 10 16; -fx-cursor: hand; -fx-pref-width: 200;"));
        // Action: Switch to Faculty Management scene
        facultyBtn.setOnAction(e -> {
            System.out.println("Faculty Management button clicked");
            UIUtil.switchScene(stage, new FacultyManagementController(stage).getScene());
        });

        Button bookBtn = new Button("📚 Book Management"); // This button is present and unchanged in functionality
        bookBtn.setStyle("-fx-background-color: linear-gradient(#f59e0b, #f97316); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 16 10 16; -fx-cursor: hand; -fx-pref-width: 200;");
        // Hover effect: Reverse gradient
        bookBtn.setOnMouseEntered(e -> bookBtn.setStyle("-fx-background-color: linear-gradient(#f97316, #f59e0b); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 16 10 16; -fx-cursor: hand; -fx-pref-width: 200;"));
        bookBtn.setOnMouseExited(e -> bookBtn.setStyle("-fx-background-color: linear-gradient(#f59e0b, #f97316); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 16 10 16; -fx-cursor: hand; -fx-pref-width: 200;"));
        // Action: Switch to Book Management scene
        bookBtn.setOnAction(e -> UIUtil.switchScene(stage, new BookManagementController(stage).getScene()));

        Button trackBtn = new Button("🔍 Track");
        trackBtn.setStyle("-fx-background-color: linear-gradient(#10b981, #059669); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 16 10 16; -fx-cursor: hand; -fx-pref-width: 200;");
        // Hover effect: Reverse gradient
        trackBtn.setOnMouseEntered(e -> trackBtn.setStyle("-fx-background-color: linear-gradient(#059669, #10b981); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 16 10 16; -fx-cursor: hand; -fx-pref-width: 200;"));
        trackBtn.setOnMouseExited(e -> trackBtn.setStyle("-fx-background-color: linear-gradient(#10b981, #059669); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 16 10 16; -fx-cursor: hand; -fx-pref-width: 200;"));
        // Action: Switch to Track scene
        trackBtn.setOnAction(e -> UIUtil.switchScene(stage, new TrackController(stage).getScene()));

        Button searchBtn = new Button("🔍 Centralized Search");
        searchBtn.setStyle("-fx-background-color: linear-gradient(#ec4899, #db2777); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 16 10 16; -fx-cursor: hand; -fx-pref-width: 200;");
        // Hover effect: Reverse gradient
        searchBtn.setOnMouseEntered(e -> searchBtn.setStyle("-fx-background-color: linear-gradient(#db2777, #ec4899); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 16 10 16; -fx-cursor: hand; -fx-pref-width: 200;"));
        searchBtn.setOnMouseExited(e -> searchBtn.setStyle("-fx-background-color: linear-gradient(#ec4899, #db2777); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 16 10 16; -fx-cursor: hand; -fx-pref-width: 200;"));
        // Action: Switch to Centralized Search scene
        searchBtn.setOnAction(e -> UIUtil.switchScene(stage, new SearchController(stage).getScene()));

        Button profileBtn = new Button("👤 Admin Profile");
        profileBtn.setStyle("-fx-background-color: linear-gradient(#6366f1, #4f46e5); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 16 10 16; -fx-cursor: hand; -fx-pref-width: 200;");
        // Hover effect: Reverse gradient
        profileBtn.setOnMouseEntered(e -> profileBtn.setStyle("-fx-background-color: linear-gradient(#4f46e5, #6366f1); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 16 10 16; -fx-cursor: hand; -fx-pref-width: 200;"));
        profileBtn.setOnMouseExited(e -> profileBtn.setStyle("-fx-background-color: linear-gradient(#6366f1, #4f46e5); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 16 10 16; -fx-cursor: hand; -fx-pref-width: 200;"));
        // Action: Switch to Admin Profile scene
        profileBtn.setOnAction(e -> UIUtil.switchScene(stage, new AdminProfileController(stage).getScene()));

        Button cleanupBtn = new Button("🧹 Cleanup Orphaned Records");
        cleanupBtn.setStyle("-fx-background-color: linear-gradient(#dc2626, #b91c1c); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 16 10 16; -fx-cursor: hand; -fx-pref-width: 200;");
        // Hover effect: Reverse gradient
        cleanupBtn.setOnMouseEntered(e -> cleanupBtn.setStyle("-fx-background-color: linear-gradient(#b91c1c, #dc2626); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 16 10 16; -fx-cursor: hand; -fx-pref-width: 200;"));
        cleanupBtn.setOnMouseExited(e -> cleanupBtn.setStyle("-fx-background-color: linear-gradient(#dc2626, #b91c1c); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 16 10 16; -fx-cursor: hand; -fx-pref-width: 200;"));
        // Action: Cleanup orphaned issued book records
        cleanupBtn.setOnAction(e -> {
            IssuedBookDAO cleanupDAO = new IssuedBookDAO();
            int removed = cleanupDAO.removeOrphanedIssuedBooks();
            if (removed > 0) {
                UIUtil.showAlert("Success", "Removed " + removed + " orphaned issued book records.", Alert.AlertType.INFORMATION);
                // Reload the dashboard to update statistics
                UIUtil.switchScene(stage, new DashboardController(stage).getScene());
            } else {
                UIUtil.showAlert("Info", "No orphaned records found.", Alert.AlertType.INFORMATION);
            }
        });

        Button entryExitBtn = new Button("📊 Entry Exit Data");
        entryExitBtn.setStyle("-fx-background-color: linear-gradient(#8b5cf6, #7c3aed); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 16 10 16; -fx-cursor: hand; -fx-pref-width: 200;");
        // Hover effect: Reverse gradient
        entryExitBtn.setOnMouseEntered(e -> entryExitBtn.setStyle("-fx-background-color: linear-gradient(#7c3aed, #8b5cf6); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 16 10 16; -fx-cursor: hand; -fx-pref-width: 200;"));
        entryExitBtn.setOnMouseExited(e -> entryExitBtn.setStyle("-fx-background-color: linear-gradient(#8b5cf6, #7c3aed); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 16 10 16; -fx-cursor: hand; -fx-pref-width: 200;"));
        // Action: Open external URL for entry exit data sheet
        entryExitBtn.setOnAction(e -> Main.getAppHostServices().showDocument("https://docs.google.com/spreadsheets/d/1d4AgSSYDlWorcXEeB355DNpgxIYN_PMLbZ7Th2l0xi4/edit?gid=0#gid=0"));

        // Add all elements to the center layout (including the new buttons)
        centerLayout.getChildren().addAll(heading, overview, studentBtn, facultyBtn, bookBtn, trackBtn, searchBtn, profileBtn, cleanupBtn, entryExitBtn);

        // Check if an admin is logged in; if not, switch to login scene
        if (Session.getLoggedInAdmin() == null) {
            UIUtil.switchScene(stage, new LoginController(stage).getScene());
            return null; // Return null as we are redirecting
        }
        return UIUtil.createScene(topBar, centerLayout);
    }
}
