// Placeholder for Session.java
package com.library.model;

public class Session {
    private static Admin loggedInAdmin;

    public static Admin getLoggedInAdmin() { return loggedInAdmin; }
    public static void setLoggedInAdmin(Admin admin) { loggedInAdmin = admin; }
    public static void logout() { loggedInAdmin = null; }
}