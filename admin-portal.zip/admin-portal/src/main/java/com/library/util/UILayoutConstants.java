package com.library.util;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Screen;

public class UILayoutConstants {
    // Use primary screen dimensions for a full-page layout
    public static final double SCENE_WIDTH = Screen.getPrimary().getVisualBounds().getWidth();
    public static final double SCENE_HEIGHT = Screen.getPrimary().getVisualBounds().getHeight();
    public static final Insets PADDING = new Insets(20);
    public static final Pos CENTER_ALIGNMENT = Pos.CENTER;

    // Basic full-screen background color for library theme
    public static final String FULL_BACKGROUND_STYLE =
        "-fx-background-color: #f0f8ff; " +
        "-fx-background-size: cover; " +
        "-fx-background-repeat: no-repeat; " +
        "-fx-background-position: center;";

    // Semi-transparent overlay for content readability
    public static final String CONTENT_BACKGROUND_STYLE =
        "-fx-background-color: rgba(255, 255, 255, 0.95); " +
        "-fx-background-radius: 15; " +
        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 20, 0, 0, 10); " +
        "-fx-border-color: rgba(255, 255, 255, 0.2); " +
        "-fx-border-radius: 15; " +
        "-fx-border-width: 1;";

    // Card-style background for smaller components
    public static final String CARD_BACKGROUND_STYLE =
        "-fx-background-color: rgba(255, 255, 255, 0.98); " +
        "-fx-background-radius: 12; " +
        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 15, 0, 0, 6); " +
        "-fx-border-color: rgba(255, 255, 255, 0.3); " +
        "-fx-border-radius: 12; " +
        "-fx-border-width: 1;";
}
