// Placeholder for UIUtil.java
package com.library.util;

import com.library.controller.UILayoutConstants;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class UIUtil {
    public static void showAlert(String title, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static boolean showConfirmation(String message) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm");
        alert.setHeaderText(null);
        alert.setContentText(message);
        return alert.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK;
    }

    public static void switchScene(Stage stage, Scene scene) {
        // Do not apply external CSS: use programmatic Java styling only
        stage.setScene(scene);
    }

    public static Button createStyledButton(String text, String startColor, String endColor) {
        Button btn = new Button(text);
        String baseStyle = String.format("-fx-background-color: linear-gradient(%s, %s); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 20 10 20; -fx-cursor: hand;", startColor, endColor);
        btn.setStyle(baseStyle);
        btn.setOnMouseEntered(e -> btn.setStyle(String.format("-fx-background-color: linear-gradient(%s, %s); -fx-text-fill: white; -fx-font-weight: 600; -fx-background-radius: 8; -fx-padding: 10 20 10 20; -fx-cursor: hand;", endColor, startColor)));
        btn.setOnMouseExited(e -> btn.setStyle(baseStyle));
        return btn;
    }

    public static Scene createScene(Parent topBar, Parent content) {
        BorderPane root = new BorderPane();
        root.setStyle(UILayoutConstants.FULL_BACKGROUND_STYLE);

        BorderPane contentPane = new BorderPane();
        contentPane.setStyle(UILayoutConstants.CONTENT_PANE_STYLE);

        if (topBar != null) {
            contentPane.setTop(topBar);
        }
        contentPane.setCenter(content);
        BorderPane.setMargin(content, UILayoutConstants.PADDING);

        root.setCenter(contentPane);
        return new Scene(root, UILayoutConstants.SCENE_WIDTH, UILayoutConstants.SCENE_HEIGHT);
    }
}
